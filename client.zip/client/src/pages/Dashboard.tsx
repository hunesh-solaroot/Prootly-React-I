import DynamicDashboard from "@/components/dashboard/DynamicDashboard";

export default function Dashboard() {
  return <DynamicDashboard />;
}
